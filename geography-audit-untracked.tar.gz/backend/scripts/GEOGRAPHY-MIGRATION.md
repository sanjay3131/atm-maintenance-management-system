# Geography mapping migration

This script is an explicit, manually executed data migration. It is not run by
the application, deployment, or test startup. It updates only banks, regions,
districts, and ATM geography references. It never deletes or rewrites jobs,
AMC records, complaints, attendance, financial records, or audit history.

## Prerequisites

- Stop application workers and scheduled jobs for the target database.
- Take a database backup and verify that it can be restored.
- Confirm MongoDB transactions are supported (replica set or sharded cluster).
- Obtain the approved client mapping. Do not invent geography or ATM mappings.
- Review current indexes, mapping output, and duplicate/orphan reports first.

The script requires the database name both from `MONGODB_URL` (loaded from
`backend/.env`) and as a separate `--target-database` argument. It will refuse
to write unless both match.

## Mapping file

Use the existing ObjectIds for bank, region, and district documents. The client
must supply all names and parent relationships, plus explicit active flags.
Only ATMs listed in `atmAssignments` are marked `MAPPED`; all other ATMs are
left with their existing IDs and marked `UNMAPPED`. Do not use partial sample
data for an apply run.

```json
{
  "banks": [
    {
      "id": "64b000000000000000000001",
      "bankName": "Client-provided bank name",
      "bankCode": "CLIENT-CODE",
      "isActive": true
    }
  ],
  "regions": [
    {
      "id": "64b000000000000000000002",
      "bankId": "64b000000000000000000001",
      "name": "Client-provided region name",
      "code": "REGION-CODE",
      "description": "",
      "isActive": true
    }
  ],
  "districts": [
    {
      "id": "64b000000000000000000003",
      "regionId": "64b000000000000000000002",
      "districtName": "Client-provided district name",
      "pinCode": "000000",
      "state": "Client-provided state",
      "isActive": true
    }
  ],
  "atmAssignments": [
    {
      "atmId": "EXISTING-ATM-BUSINESS-ID",
      "bankId": "64b000000000000000000001",
      "regionId": "64b000000000000000000002",
      "districtId": "64b000000000000000000003"
    }
  ]
}
```

The example values above are placeholders only; they are not valid client
mapping data. Each ATM may appear at most once and must reference a consistent
bank → region → district chain. The script validates existing geography IDs
and ATM business IDs before applying.

## Dry run and apply

From `backend/`, use the exact database name from `MONGODB_URL`:

```sh
npm run geography:migrate -- --target-database=<database-name>
npm run geography:migrate -- \
  --target-database=<database-name> \
  --mapping=/absolute/path/to/approved-geography.json
```

Dry runs report collection counts, orphaned geography references, inconsistent
ATM hierarchies, duplicates under the new uniqueness rules, existing indexes,
and mapping coverage. Resolve mapping errors and review the report before
proceeding.

After confirming the backup and approving the report, apply explicitly:

```sh
npm run geography:migrate -- \
  --target-database=<database-name> \
  --mapping=/absolute/path/to/approved-geography.json \
  --apply \
  --confirm=APPLY-GEOGRAPHY-MAPPING \
  --backup-confirmed
```

The apply operation uses a MongoDB transaction with a 30-second commit limit.
It preserves document IDs and operational collections. Existing unmapped bank
records are deactivated; unmapped regions/districts are deactivated and marked
`UNMAPPED`; unmapped ATMs keep their current geography references but are
marked `UNMAPPED`. A failure aborts the transaction.

## Index deployment and rollback

The application schemas define the new bank-/parent-scoped unique indexes.
The migration script only reports existing indexes; it does not drop or create
indexes. Review legacy constraints and duplicate reports, then schedule index
changes separately using the project's database deployment procedure.

Rollback is a restore from the verified pre-migration database backup. Do not
attempt to reverse the mapping by guessing old values, and do not restore only
the geography collections if they have changed since the backup. Keep the
application and scheduled jobs stopped until the migration and index deployment
have been reviewed.
